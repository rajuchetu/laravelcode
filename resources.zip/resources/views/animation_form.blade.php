@extends('layout')
@section('container')
<h3>Animation Add</h3></br>
<a href="{{url('animation')}}">
<button type="button"class="btn btn-success">
    Back 
</button>
</a>
  <div class="row m-t-30">
  <div class="col-md-12">
      <div class="row">
                            <div class="col-lg-12">
						
							<div class="card">
                                    
                                    <div class="card-body">
                                        
                                        
                                        <form action="{{route('animation.insert')}}" method="post"> 
                                          @csrf										
										<div class="form-group">
                                                <label for="animation_name" class="control-label mb-1">animation_name</label>
                                                <input id="animationt_name" name="animation_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
												@error('animation_name')
												{{$message}}
												@enderror
                                            </div>
											
                                         
								                <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                   submit
                                                   
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                               
                            </div> 
                           
      </div>
	  </div>
	  </div>
	  
 
@endsection

