@extends('layout')
@section('container')
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
<h3>Animation</h3></br>
<a href="{{url('animation/add')}}">
<button type="button"class="btn btn-success">
Add Animation
</button>
</a>
  <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>animation_name</th>
                                                <th>Action</th>
                                                
												</tr>
                                        </thead>
                                        <tbody>
										@foreach($data as $list)
                                            
											<tr>
                                                <td>{{$loop->iteration}}</td>
                                                <td>{{$list->animation_name}}</td>
                                                  
							                      <td>
												<a href ="{{url('animation/delete/'.$list->id)}}"><button type="button" class="btn btn-danger">Delete</button></a>
												
												<a href ="{{url('animation/edit/'.$list->id)}}"><button type="button" class="btn btn-danger">Edit</button></
												</td>
                                            </tr
											@endforeach
                                          
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
                      
                     @endsection

