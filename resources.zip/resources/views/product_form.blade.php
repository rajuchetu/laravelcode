@extends('layout')
@section('container')
<h3>Product_Add</h3>
<a href="{{url('product')}}"></br>
<button type="button"class="btn btn-success">
    Back 
</button>
</a>
  <div class="row m-t-30">
  <div class="col-md-12">
      <div class="row">
                            <div class="col-lg-12">
						
							<div class="card">
                                    
                                    <div class="card-body">
                                        
                                        
                                        <form action="{{route('product.insert')}}" method="post" enctype="multipart/form-data"> 
                                          @csrf										
										<div class="form-group">
                                                <label for="product_name" class="control-label mb-1">product_name</label>
                                                <input id="product_name" name="product_name" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
												@error('product_name')
												{{$message}}
												@enderror
                                            </div>
											
                                           <div class="form-group">
                                                <label for="product_info" class="control-label mb-1">product_info</label>
                                                <input id="product_info" name="product_info" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
												@error('product_info')
												{{$message}}
												@enderror
                                            </div>                                         
                                             
											 <div class="form-group">
                                                <label for="product_image" class="control-label mb-1">product_image</label>
                                                <input type="file" id="product_image" name="image"  class="form-control"  >
												
                                            </div>        
                                            
										
                                          <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                   submit
                                                   
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                               
                            </div> 
                           
      </div>
	  </div>
	  </div>
	  
 
@endsection

