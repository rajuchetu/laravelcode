@extends('layout')
@section('container')
<h3>User_Add</h3>
<a href="{{url('admin')}}">
<button type="button"class="btn btn-success">
    Back 
</button>
</a>
  <div class="row m-t-30">
  <div class="col-md-12">
      <div class="row">
                            <div class="col-lg-12">
						
							<div class="card">
                                    
                                    <div class="card-body">
                                        
                                        
                                       <form method="post" action="{{url('user/update/'.$UserEdit->id)}}">

@method('PATCH')
@csrf
       
	   <div class="form-group">
<label for="name">name:
</label><br/><br/>
<input type="text" class="form-control" name="name"value="{{$UserEdit->name}}"><br/><br/>
</div>

<div class="form-group">
<label for="email">email:
</label><br/><br/>
<input type="text" class="form-control" name="email"value="{{$UserEdit->email}}"><br/><br/>
</div>

<div class="form-group">
<label for="phone_no">phone_no:
</label><br/><br/>
<input type="text" class="form-control" name="phone_no"value="{{$UserEdit->phone_no}}"><br/><br/>
</div>

<div class="form-group">
<label for="password">password:
</label><br/><br/>
<input type="text" class="form-control" name="password"value="{{$UserEdit->password}}"><br/><br/>
</div>

<br/> 






<button type="submit" class="btn-btn">Update</button>
</form>

                                    </div>
                                </div>
                               
                            </div> 
                           
      </div>
	  </div>
	  </div>
	  
 
@endsection

