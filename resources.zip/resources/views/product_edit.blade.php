@extends('layout')
@section('container')
<h3>Product_Add</h3></br>
<a href="{{url('product')}}">
<button type="button"class="btn btn-success">
    Back 
</button>
</a>
  <div class="row m-t-30">
  <div class="col-md-12">
      <div class="row">
                            <div class="col-lg-12">
						
							<div class="card">
                                    
                                    <div class="card-body">
                                        
                                        
                                       <form method="post" action="{{url('product/update/'.$EditProduct->id)}}"enctype="multipart/form-data">

@method('PATCH')
@csrf
       
	   <div class="form-group">
<label for="product_name">product_name:
</label><br/><br/>
<input type="text" class="form-control" name="product_name"value="{{$EditProduct->product_name}}"><br/><br/>
</div>

<div class="form-group">
<label for="product_info">product_info:
</label><br/><br/>
<input type="text" class="form-control" name="product_info"value="{{$EditProduct->product_info}}"><br/><br/>
</div>

<div class="form-group">
<label for="product_image">product_image:
</label><br/><br/>
<input type="file" class="form-control" name="product_image"value="{{$EditProduct->product_image}}">
<img src="{{ asset('uploads/' . $EditProduct->product_image) }}" width="195" height="70"><br/><br/>
</div>

<br/> 


<button type="submit" class="btn-btn">Update</button>
</form>

                                    </div>
                                </div>
                               
                            </div> 
                           
      </div>
	  </div>
	  </div>
	  
 
@endsection

