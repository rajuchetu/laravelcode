@extends('layout')
@section('container')
<h3>Animation_Add</h3></br>
<a href="{{url('animation')}}">
<button type="button"class="btn btn-success">
    Back 
</button>
</a>
  <div class="row m-t-30">
  <div class="col-md-12">
      <div class="row">
                            <div class="col-lg-12">
						
							<div class="card">
                                    
                                    <div class="card-body">
                                        
                                        
                                       <form method="post" action="{{url('animation/update/'.$AnimationEdit->id)}}">

@method('PATCH')
@csrf
       
	   <div class="form-group">
<label for="animation_name">animation_name:
</label><br/><br/>
<input type="text" class="form-control" name="animation_name"value="{{$AnimationEdit->animation_name}}"><br/><br/>
</div>

<br/> 

<button type="submit" class="btn-btn">Update</button>
</form>

                                    </div>
                                </div>
                               
                            </div> 
                           
      </div>
	  </div>
	  </div>
	  
 
@endsection

