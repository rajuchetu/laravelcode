@extends('layout')
@section('container')
<h3>User_Add</h3>
<a href="{{url('admin')}}">
<button type="button"class="btn btn-success">
    Back 
</button>
</a>
  <div class="row m-t-30">
  <div class="col-md-12">
      <div class="row">
                            <div class="col-lg-12">
						
							<div class="card">
                                    
                                    <div class="card-body">
                                        
                                        
                                        <form action="{{route('user.insert')}}" method="post"> 
                                          @csrf										
										<div class="form-group">
                                                <label for="name" class="control-label mb-1">name</label>
                                                <input id="name" name="name" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
												@error('name')
												{{$message}}
												@enderror
                                            </div>
											
                                           <div class="form-group">
                                                <label for="email" class="control-label mb-1">email</label>
                                                <input id="email" name="email" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
												@error('email')
												{{$message}}
												@enderror
                                            </div>                                         
                                             
											 <div class="form-group">
                                                <label for="phone_no" class="control-label mb-1">phone_no</label>
                                                <input id="phone_no" name="phone_no" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
												@error('phone_no')
												{{$message}}
												@enderror
                                            </div>        
                                            
											<div class="form-group">
                                                <label for="password" class="control-label mb-1">password</label>
                                                <input id="password" name="password" type="text" class="form-control" aria-required="true" aria-invalid="false" required>
												@error('password')
												{{$message}}
												@enderror
                                            </div>        
                                          
                                           
                                           
                                            <div>
                                                <button id="payment-button" type="submit" class="btn btn-lg btn-info btn-block">
                                                   submit
                                                   
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                               
                            </div> 
                           
      </div>
	  </div>
	  </div>
	  
 
@endsection

