@extends('layout')
@section('container')
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
<h3>User</h3></br>
<a href="{{url('admin/category')}}">
<button type="button"class="btn btn-success">
Add User
</button>
</a>
  <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>name</th>
                                                <th>email</th> 
												<th>phone_no</th>
												<th>password</th>
                                                <th>Action</th>
                                                
												</tr>
                                        </thead>
                                        <tbody>
										@foreach($data as $list)
                                            
											<tr>
                                                <td>{{$loop->iteration}}</td>
                                                <td>{{$list->name}}</td>
                                                 <td>{{$list->email}}</td> 
												 <td>{{$list->phone_no}}</td>
												 <td>{{$list->password}}</td>
											      
												  <td>
												<a href ="{{url('user/delete/'.$list->id)}}"><button type="button" class="btn btn-danger">Delete</button></a>
												
												<a href ="{{url('user/edit/'.$list->id)}}"><button type="button" class="btn btn-danger">Edit</button></
												</td>
                                            </tr
											@endforeach
                                          
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
                      
                     @endsection

