@extends('layout')
@section('container')
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
<h3>Product</h3></br>
<a href="{{url('product/add')}}">
<button type="button"class="btn btn-success">
Add Product
</button>
</a>
  <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
                                <div class="table-responsive m-b-40">
                                    <table class="table table-borderless table-data3">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>product_name</th>
                                                <th>product_info</th> 
												<th>product_image</th>
											    <th>Action</th>
                                                
												</tr>
                                        </thead>
                                        <tbody>
										@foreach($data as $list)
                                            
											<tr>
                                                <td>{{$loop->iteration}}</td>
                                                <td>{{$list->product_name}}</td>
                                                 <td>{{$list->product_info}}</td> 
												 <td><img src="{{ asset('uploads/' . $list->product_image) }}" width="195" height="70"></td>
												
											      <td>
												<a href ="{{url('product/delete/'.$list->id)}}"><button type="button" class="btn btn-danger">Delete</button></a>
												
												<a href ="{{url('product/edit/'.$list->id)}}"><button type="button" class="btn btn-danger">Edit</button></
												</td>
                                            </tr
											@endforeach
                                          
                                        </tbody>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
                      
                     @endsection

