				 
@extends('layout')
@section('container')
@if(session()->has('message'))
    <div class="alert alert-success">
        {{ session()->get('message') }}
    </div>
@endif
<h3>Order</h3></br>

  <div class="row m-t-30">
                            <div class="col-md-12">
                                <!-- DATA TABLE-->
								<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script src = "http://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js" defer ></script>
								 <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
							<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css"/>

<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.4.1/css/buttons.dataTables.min.css">
<script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
 <script type="text/javascript" src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
                                <div class="table-responsive m-b-25">
                                    <table class="table table-borderless table-data3"  id="example">
                                        <thead>
                                            <tr>
                                                 <th>No</th>
                                                <th>name</th>
                                                <th>email</th> 
												<th>phone_no</th>
											    <th>product_name</th> 
												<th>quantity</th>
                                                
												</tr>
                                        </thead>
                                        <tbody>
										@foreach($data as $list)
                                            
											<tr>
                                                <td>{{$loop->iteration}}</td>
                                                <td>{{$list->name}}</td>
                                                 <td>{{$list->email}}</td>
												 <td>{{$list->phone_no}}</td>
												 <td>{{$list->product_name}}</td>
												 <td>{{$list->quantity}}</td>
											
												
                                            </tr
											@endforeach
                                          
                                        </tbody>
										<tfoot>
            <tr>
                <th>no</th>
				<th>name</th>
                <th>email</th>
                <th>phone_no</th>
                <th>product_name</th>
                <th>quantity</th>
                
            </tr>
        </tfoot>
                                    </table>
                                </div>
                                <!-- END DATA TABLE-->
                            </div>
                        </div>
                 
				   <script>
	$(document).ready(function() {
    // Setup - add a text input to each footer cell
    $('#example tfoot th').each( function () {
        var title = $(this).text();
        $(this).html( '<input type="text" placeholder="Search '+title+'" />' );
    } );
 
    // DataTable
    var table = $('#example').DataTable({
        initComplete: function () {
            // Apply the search
            this.api().columns().every( function () {
                var that = this;
 
                $( 'input', this.footer() ).on( 'keyup change clear', function () {
                    if ( that.search() !== this.value ) {
                        that
                            .search( this.value )
                            .draw();
                    }
                } );
            } );
        }
    });
 
} );			   
  
 </script>
                     @endsection
     
					
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 
					 


