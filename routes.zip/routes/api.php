<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\User;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

//Route::middleware('auth:api')->get('/user', function (Request $request) {
  //  return $request->user();
//});
Route::post('register','UserController@register');
Route::post('login','UserController@login');
Route::any('productindex','ProductController@productindex');
Route::any('product/search','ProductController@product_search');
Route::any('animation/get','AnimationController@animation_get');
Route::any('animation/search','AnimationController@animation_search');
Route::any('forgot/password','UserController@forgot_password');
Route::any('send/otp','UserController@send_otp');
Route::any('change/password','UserController@change_password');
Route::any('confirm/order','OrderController@confirm_order');
Route::any('product/id','ProductController@product_id_get');
Route::any('animation/id','AnimationController@animation_id_get');