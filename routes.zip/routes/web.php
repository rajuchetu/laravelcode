<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});
Route::any('login','AdminController@index');
Route::any('logout','AdminController@logout');
Route::any('admin/auth','AdminController@admin_login')->name('admin.auth');
 Route::any('forgot/password','AdminController@forgot_password');
 Route::any('forgotten/password','AdminController@forgotten')->name('forgotten.password');
 Route::any('dashboard','AdminController@dashboard');
 Route::any('admin','AdminController@admin');
 Route::any('admin/category','AdminController@admin_category');
 Route::any('user/insert','AdminController@user_insert')->name('user.insert');
 Route::any('user/edit/{id}','AdminController@user_edit');
 Route::any('user/update/{id}','AdminController@user_update');
 Route::any('user/delete/{id}','AdminController@delete');
 Route::any('product','ProductController@product');
 Route::any('product/add','ProductController@product_add'); 
 Route::any('product/insert','ProductController@product_insert')->name('product.insert'); 
 Route::any('product/edit/{id}','ProductController@product_edit');
 Route::any('product/update/{id}','ProductController@product_update');
 Route::any('product/delete/{id}','ProductController@delete');
 Route::any('animation','AnimationController@animation'); 
 Route::any('animation/add','AnimationController@animation_add'); 
 Route::any('animation/insert','AnimationController@animation_insert')->name('animation.insert'); 
 Route::any('animation/edit/{id}','AnimationController@animation_edit');
 Route::any('animation/update/{id}','AnimationController@animation_update');
 Route::any('animation/delete/{id}','AnimationController@animation_delete'); 
 Route::any('order','OrderController@order');