<?php

namespace App\Http\Controllers;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */ 
	 public function register(Request $request)
	 {   
	       $validator = validator()->make(request()->all(), [
           'name'=>'required',
	       'email'=>'required|unique:users',
	       'phone_no'=>'required|unique:users',
	       'password'=>'required'
             ]);

        if ($validator->fails())
       {
        return response($validator->messages(), 200);
        }
		
         
		 $user= new User;
		 
		 $user->name= $request->input('name');
		 $user->email= $request->input('email');
		 $user->phone_no= $request->input('phone_no'); 
		 $user->password= $request->input('password');
	      $user->save();
         if(isset($user)){
		 return response()->json(['status'=>200,'message'=>"Register successful"]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"Something went wrong try again."]); 
		}
	 }
	 
	 
    public function login(Request $request)
    {  
	     
		  $email=$request->post('email');
		  $password=$request->post('password');
		
		  $result = User::where("email" , $email)->orWhere('phone_no' , $email)->where("password" , $password)->get();  
         if(isset($result['0']->id)){
		 return response()->json(['status'=>200,'message'=>"login success",'data'=>$result]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"incorrect credentails."]); 
		}
	}
   public function forgot_password(Request $request)
   {
	   $email=$request->post('email');
   $result = User::where("email" , $email)->orWhere('phone_no' , $email)->get(); 
  
   if(isset($result['0']->id)){
	 $forget=$result['0']->id; 
    $otp=rand(6,1000000);
	
	 $user=User::find($forget); 
	 $user->otp=$otp;
  $user->save();
  $email= $result['0']->email;
   $to = $email;
         $subject = "This is subject";
         
         $message = $otp; 
         $message .= "<h1>This is headline.</h1>";
         
         $header = "From:abc@somedomain.com \r\n";
        
         
         
         $retval = mail ($to,$subject,$message,$header);
         
         if( $retval == true ) {
            return response()->json(['status'=>200,'message'=>"login success",'data'=>$result]);
         }else {
            return response()->json(['status'=>200,'message'=>"login success",]);
         }
		 	
     } else{
			 return response()->json(['status'=>200,'message'=>"this account not access"]); 
		}
   
   }
  public function send_otp(Request $request)
  {   
           $id=$request->post('user_id');
		  $otp=$request->post('otp');

        $resultotp = User::where("id" , $id)->where("otp" , $otp)->get();  
         if(isset($resultotp['0']->id)){
		 return response()->json(['status'=>200,'message'=>"login success",'data'=>$resultotp]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"incorrect otp."]); 
		}


}
 public function change_password(Request $request)
  { 
          $id=$request->post('user_id');
		  $changepassword=$request->post('change_password');
		   $user=User::find($id); 
	 $user->change_password=$changepassword;
  $user->save();
		  //$ChangeResult = User::where("id" , $id)->where("change_password" , $changepassword)->get();  
         if(isset($user->save()['0']->id)){
		 return response()->json(['status'=>200,'message'=>"password change success",'data'=>$ChangeResult]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"try again."]); 
		}

}
}