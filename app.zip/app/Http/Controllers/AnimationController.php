<?php

namespace App\Http\Controllers;

use App\Animation;
use Illuminate\Http\Request;

class AnimationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
  public function animation_get()
    {
        $AnimationResult['data']=Animation::all();
		if($AnimationResult['data']){
		 return response()->json(['status'=>200,'message'=>$AnimationResult['data']]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"no record found."]); 
		}
    }
     public function animation_search(Request $request)
    {  
         $AnimationName=$request->input('animation_name');
		
		 $Animationsearch=Animation::where('animation_name','like',"%{$AnimationName}%")->get();
  
  if(count($Animationsearch)){
		 return response()->json(['status'=>200,'message'=>$Animationsearch]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"no record found."]); 
		}
} 	


       public function animation()
       {
        $result['data']=Animation::all();
	  return view('animation',$result);
	   
        }
 
       public function animation_add()
       {
       return view('animation_form');
       }

	  public function animation_insert(Request $request)
     {
	   $request->validate([
	  'animation_name'=>'required',
	 
	 ]);
	   $model=new Animation();
	  
	  $model->animation_name=$request->post('animation_name');
	    $model->save();
	   $request->session()->flash('message','animation insert');
	   return redirect('animation');
	 }
	 
	 public function animation_edit(Request $request,$id)
     {   
        $AnimationEdit=Animation::find($id);
		return view('animation_edit',compact('AnimationEdit'));
     } 
	 
	 public function animation_update(Request $request,$id)
     {
	      
	  $request->validate([
	  'animation_name'=>'required',
	  
	 ]); 
		 $AnimationEdit=Animation::find($id); 
		
		 $AnimationEdit->animation_name=$request->post('animation_name');
	    $AnimationEdit->save();
	     $request->session()->flash('message','animation updated');
	   return redirect('animation');
	} 
	 
	 public function animation_delete(Request $request,$id)
	 {
	 $AnimationDelete=Animation::find($id);
	 $AnimationDelete->delete();
	 return back()->with('success','Record delete succrssfully');
	 }  
	 
	 
	 public function animation_id_get(Request $request)
	{
      $request->validate([
	  'animation_by_id'=>'required',
		 ]); 
		  
		 $GetBy=$request->post('animation_by_id'); 
		 $GetAnimation=Animation::find($GetBy); 
		
		 if($GetAnimation){
		 return response()->json(['status'=>200,'message'=> $GetAnimation]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"no record found."]); 
		}
	}
}