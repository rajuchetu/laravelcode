<?php

namespace App\Http\Controllers;

use App\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function productindex()
    {         
        $result['data']=Product::all();
		
		if($result['data']){
		 return response()->json(['status'=>200,'message'=>$result['data']]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"no record found."]); 
		}
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function product_search(Request $request)
    {  
         $ProductName=$request->input('product_name');
		
		 $search=Product::where('product_name','like',"%{$ProductName}%")->get();
  
  if(count($search)){
		 return response()->json(['status'=>200,'message'=>$search]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"no record found."]); 
		}
   
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
  

    /**
     * Display the specified resource.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
   
      public function product()
    {
        $result['data']=Product::all();
        return view('product',$result);
    }
    
	
	public function product_add()
    {
        return view('product_form');
    }
 
    
    public function product_insert(Request $request)
    {
	   $request->validate([
	  'product_name'=>'required|unique:products',
	  'product_info'=>'required',
	  
	  
	 ]);
	   $ProductAdd=new Product();
	
	$ProductAdd->product_name=$request->post('product_name');
	$ProductAdd->product_info=$request->post('product_info');
	
	
	if($request->hasFile('image')){
				$value=$request->file('image');
	        
	$file_name = str_replace(' ', '_', basename($value->getClientOriginalName(), '.'.$value->getClientOriginalExtension()));
	$code=mt_rand(1000,9999);
    $filename = $file_name.'-'.time().".".$value->getClientOriginalExtension();
	$file_path=public_path()."/uploads/".$filename;
    $value->move(public_path()."/uploads/",$filename);
	$ProductAdd->product_image=$filename;
	}else{
            $ProductAdd->product_image='';
        }
	
	
	
	 $ProductAdd->save();
	   $request->session()->flash('message','product insert');
	   return redirect('product');
        
    } 
	
      public function product_edit(Request $request,$id)
	  { 
        $EditProduct=Product::find($id);
		
		return view('product_edit',compact('EditProduct'));
      }
	
	
	public function product_update(Request $request,$id)
	{
	
	  $request->validate([
	  'product_name'=>'required',
	  'product_info'=>'required',
	  //'product_image'=>'required',
	 
	 ]); 
		 $EditProduct=Product::find($id); 
		
		 $EditProduct->product_name=$request->post('product_name');
	     $EditProduct->product_info=$request->post('product_info');
	     //$EditProduct->product_image=$request->post('product_image');
	    
		
		if($request->hasFile('product_image')){
				$value=$request->file('product_image');
	    // $path = public_path()."/uploads/".$EditProduct['product_image'];
		// chown($path, 666);
    // unlink($path);  
Storage::delete('public/uploads/'.$EditProduct['product_image']);	
	$file_name = str_replace(' ', '_', basename($value->getClientOriginalName(), '.'.$value->getClientOriginalExtension()));
	$code=mt_rand(1000,9999);
    $filename = $file_name.'-'.time().".".$value->getClientOriginalExtension();
	$file_path=public_path()."/uploads/".$filename;
    $value->move(public_path()."/uploads/",$filename);
	$EditProduct->product_image=$filename;

	}else{
        $EditProduct->product_image=$EditProduct['product_image'];
        }
	     $EditProduct->save();
	     $request->session()->flash('message','user updated');
	   return redirect('product');
	} 
	
	
	public function delete(Request $request,$id)
    { 
       $productdelet=Product::find($id);
	$productdelet->delete();
	return back()->with('success','Record delete succrssfully');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function product_id_get(Request $request)
	{
      $request->validate([
	  'product_by_id'=>'required',
		 ]); 
		  
		 $GetProduct=$request->post('product_by_id'); 
		 $Product=Product::find($GetProduct); 
		
		 if($Product){
		 return response()->json(['status'=>200,'message'=> $Product]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"no record found."]); 
		}
    }
}
