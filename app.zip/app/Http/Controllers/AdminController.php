<?php

namespace App\Http\Controllers;

use App\Admin;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Auth;
class AdminController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */  public function index(Request $request)
    {
		if($request->session()->has('ADMIN_LOGIN')){
			
		}else{
			
		return view('login');
		}
       return view('login');
    }
	
    public function admin_login(Request $request)
	{  
		$email=$request->post('email');
		$password=$request->post('password');
		
		$result=Admin::where(['email'=>$email,'password'=>$password])->get();
		if(isset($result['0']->id)){
			$request->session()->put('ADMIN_LOGIN',true);
			$request->session()->put('ADMIN_ID',$result['0']->id);
			return redirect('admin');
		}else{
			$request->session()->flash('error','please enter valid login details');
		    return redirect('login');
		}     
     
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function forgot_password(Request $request)
    { if($request->session()->has('FORGOT_PASSWORD')){
			
		}else{
			
		return view('forgotPassword');
		}
       return view('forgotPassword');
        
    }

    
    public function forgotten(Request $request)
    {      
        $email=$request->post('email'); 
		$result = Admin::where("email" , $email)->orWhere('phone_no' , $email)->get(); 
  
		
    }
     public function dashboard()
    {
    
    return view('dashboard');
    
     }
    
	
	
	
	public function admin()
    {
        $result['data']=User::all();
        return view('admin',$result);
    }

   
    public function admin_category()
    {
        return view('admin_category');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Product  $product
     * @return \Illuminate\Http\Response
     */
    public function user_insert(Request $request)
    {
	   $request->validate([
	  'name'=>'required',
	  'email'=>'required|unique:users',
	  'phone_no'=>'required|unique:users',
	  'password'=>'required',
	 ]);
	   $model=new User();
	
	$model->name=$request->post('name');
	$model->email=$request->post('email');
	$model->phone_no=$request->post('phone_no');
	$model->password=$request->post('password');
	 $model->save();
	   $request->session()->flash('message','user insert');
	   return redirect('admin');
        
    } 
	
	public function user_edit(Request $request,$id)
    {   
        $UserEdit=User::find($id);
		return view('user_edit',compact('UserEdit'));
    }
	
	public function user_update(Request $request,$id)
	{
	   
	  $request->validate([
	  'name'=>'required',
	  'email'=>'required',
	  'phone_no'=>'required',
	  'password'=>'required',
	 ]); 
		 $UserEdit=User::find($id); 
		
		 $UserEdit->name=$request->post('name');
	     $UserEdit->email=$request->post('email');
	     $UserEdit->phone_no=$request->post('phone_no');
	     $UserEdit->password=$request->post('password');
	     $UserEdit->save();
	     $request->session()->flash('message','user updated');
	   return redirect('admin');
	} 
	public function delete(Request $request,$id)
    { 
       $userdelet=User::find($id);
	$userdelet->delete();
	return back()->with('success','Record delete succrssfully');
    }
	

public function logout()
{
   
    Session::flush();
    return redirect('login');
 }
}
