<?php

namespace App\Http\Controllers;
use App\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
class OrderController extends Controller
{
   
	 public function confirm_order(Request $request)
	 { 
	    $request->validate([
	    'name'=>'required',
	    'email'=>'required', 
	     'phone_no'=>'required', 
	    'product_name'=>'required',
	    'quantity'=>'required',
	  
	  ]);
	  	   $Confirm= new Order;
           $Confirm->name=$request->post('name'); 
		  $Confirm->email=$request->post('email');
		  $Confirm->phone_no=$request->post('phone_no'); 
		  $Confirm->product_name=$request->post('product_name'); 
		  $Confirm->quantity=$request->post('quantity');
		  $Confirm->save();
      
	  if($Confirm->save()){
		 return response()->json(['status'=>200,'message'=>"order placed successfully"]); 	
		}else{
			 return response()->json(['status'=>200,'message'=>"somthing went wrong "]); 
		}
		 
	 }
	    
		public function order()
    {
        $result['data']=Order::all();
        return view('order',$result);
    }
    
}